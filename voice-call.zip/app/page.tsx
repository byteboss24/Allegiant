"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Mic, MicOff, Phone, PhoneOff, Volume2, VolumeX } from "lucide-react"

export default function VoiceCallPage() {
  const [isCallActive, setIsCallActive] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [isSpeakerOn, setIsSpeakerOn] = useState(true)
  const [connectionStatus, setConnectionStatus] = useState("disconnected")

  const websocketRef = useRef<WebSocket | null>(null)
  const audioContextRef = useRef<AudioContext | null>(null)
  const micStreamRef = useRef<MediaStream | null>(null)
  const audioSourceRef = useRef<MediaStreamAudioSourceNode | null>(null)
  const audioDestinationRef = useRef<MediaStreamAudioDestinationNode | null>(null)

  // Initialize WebSocket connection
  const initializeWebSocket = () => {
    // Replace with your actual WebSocket server URL
    const wsUrl = "wss://your-websocket-server.com"

    websocketRef.current = new WebSocket(wsUrl)

    websocketRef.current.onopen = () => {
      setConnectionStatus("connected")
      console.log("WebSocket connection established")
    }

    websocketRef.current.onclose = () => {
      setConnectionStatus("disconnected")
      console.log("WebSocket connection closed")
    }

    websocketRef.current.onerror = (error) => {
      setConnectionStatus("error")
      console.error("WebSocket error:", error)
    }

    websocketRef.current.onmessage = (event) => {
      // Handle incoming audio data
      if (audioContextRef.current && audioDestinationRef.current) {
        const audioData = JSON.parse(event.data)
        // Process incoming audio data
        // This is a simplified example - actual implementation would decode the audio data
        console.log("Received audio data", audioData)
      }
    }
  }

  // Initialize audio context and microphone
  const initializeAudio = async () => {
    try {
      audioContextRef.current = new AudioContext()

      // Get microphone access
      micStreamRef.current = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: false,
      })

      // Create audio source from microphone
      audioSourceRef.current = audioContextRef.current.createMediaStreamSource(micStreamRef.current)

      // Create audio destination for output
      audioDestinationRef.current = audioContextRef.current.createMediaStreamDestination()

      // Connect source to destination
      audioSourceRef.current.connect(audioDestinationRef.current)

      console.log("Audio initialized successfully")
    } catch (error) {
      console.error("Error initializing audio:", error)
    }
  }

  // Start call
  const startCall = async () => {
    await initializeAudio()
    initializeWebSocket()
    setIsCallActive(true)
  }

  // End call
  const endCall = () => {
    if (websocketRef.current) {
      websocketRef.current.close()
    }

    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach((track) => track.stop())
    }

    if (audioContextRef.current) {
      audioContextRef.current.close()
    }

    setIsCallActive(false)
    setConnectionStatus("disconnected")
  }

  // Toggle mute
  const toggleMute = () => {
    if (micStreamRef.current) {
      micStreamRef.current.getAudioTracks().forEach((track) => {
        track.enabled = isMuted
      })
      setIsMuted(!isMuted)
    }
  }

  // Toggle speaker
  const toggleSpeaker = () => {
    setIsSpeakerOn(!isSpeakerOn)
    // Implementation would depend on how you're playing back audio
  }

  // Send audio data through WebSocket
  const sendAudioData = (audioData: any) => {
    if (websocketRef.current && websocketRef.current.readyState === WebSocket.OPEN) {
      websocketRef.current.send(JSON.stringify(audioData))
    }
  }

  // Cleanup on component unmount
  useEffect(() => {
    return () => {
      if (websocketRef.current) {
        websocketRef.current.close()
      }

      if (micStreamRef.current) {
        micStreamRef.current.getTracks().forEach((track) => track.stop())
      }

      if (audioContextRef.current) {
        audioContextRef.current.close()
      }
    }
  }, [])

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-center">Voice Call</CardTitle>
          <div className="flex justify-center">
            <Badge variant={connectionStatus === "connected" ? "default" : "destructive"} className="mt-2">
              {connectionStatus === "connected" ? "Connected" : "Disconnected"}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center mb-6">
            <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center">
              <Phone className={`h-12 w-12 ${isCallActive ? "text-primary" : "text-muted-foreground"}`} />
            </div>
          </div>

          {isCallActive && (
            <div className="flex justify-center space-x-4 mb-6">
              <Button variant="outline" size="icon" className={isMuted ? "bg-red-100" : ""} onClick={toggleMute}>
                {isMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
              </Button>

              <Button
                variant="outline"
                size="icon"
                className={!isSpeakerOn ? "bg-red-100" : ""}
                onClick={toggleSpeaker}
              >
                {isSpeakerOn ? <Volume2 className="h-5 w-5" /> : <VolumeX className="h-5 w-5" />}
              </Button>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-center">
          {!isCallActive ? (
            <Button onClick={startCall} className="px-8">
              Start Call
            </Button>
          ) : (
            <Button variant="destructive" onClick={endCall} className="px-8">
              <PhoneOff className="mr-2 h-4 w-4" /> End Call
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  )
}

